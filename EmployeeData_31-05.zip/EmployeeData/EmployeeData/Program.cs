﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeData

{
    public class Menu
    {
        public string EmpName { get; set; }
        public string EmpNo { get; set; }
        public string EmpMoNo { get; set; }
        public string EmpCity { get; set; }
        public string EmpExp { get; set; }
        public void menu()
        {
            Console.WriteLine("1.Add new Employee");
            Console.WriteLine("2.Display All Employee");
            Console.WriteLine("3.Search Employee");
            Console.WriteLine("4.Remove Employee");
            Console.WriteLine("5.Exit");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            List<Menu> EmpData = new List<Menu>();
            startconsole:
            Menu obj = new Menu();
            obj.menu();
            Console.Write("Enter Your Choice:");
            int Choice = Convert.ToInt32(Console.ReadLine());
            switch(Choice)
            {
                case 1:
                    Console.Write("Enter Employee Name:");
                    String Name = Console.ReadLine();
                    Console.Write("Enter Employee Number:");
                    string Number = Console.ReadLine();
                    Console.Write("Enter Employee City:");
                    string City = Console.ReadLine();
                    Console.Write("Enter Employee Phone No:");
                    string MoNo = Console.ReadLine();
                    Console.Write("Enter Employee Experiance in Year:");
                    string Exp = Console.ReadLine();
                    Console.WriteLine("Employee details added successfully");
                    EmpData.Add(new Menu
                    {
                       EmpName = Name,
                       EmpNo = Number,
                       EmpCity = City,
                       EmpExp  = Exp,
                       EmpMoNo = MoNo,
                    });
                    break;
                case 2:
                    if (EmpData.Count == 0)
                    {
                        Console.WriteLine("There is not any data in Employee List");
                    }
                    else
                    {
                        Console.WriteLine(string.Format("{0,-15}{1,-15}{2,-15}{3,-15}{4,15}", "Enumber", "Name", "City", "Experiance", "Mobile No"));
                        Console.WriteLine("==========================================================================================");
                        foreach (Menu emp in EmpData)
                        {
                            Console.WriteLine(string.Format("{0,-15}{1,-15}{2,-15}{3,-15}{4,15}", emp.EmpNo, emp.EmpName, emp.EmpCity, emp.EmpExp, emp.EmpMoNo));
                        }
                    }
                    break;
                case 3:
                    if (EmpData.Count == 0)
                    {
                        Console.WriteLine("There is no data for search");
                    }
                    else
                    {
                        Console.Write("Enter Employee Number For Search: ");
                        String SearchEmp = Console.ReadLine();
                        bool exist = false;
                        foreach (Menu e in EmpData)
                        {
                            if (e.EmpNo == SearchEmp)
                            {
                                Console.WriteLine(string.Format("{0,-15}{1,-15}{2,-15}{3,-15}{4,15}", "Enumber", "Name", "City", "Experiance","Mobile No"));
                                Console.WriteLine("===================================================================================");
                                Console.WriteLine(string.Format("{0,-15}{1,-15}{2,-15}{3,-15}{4,15}", e.EmpNo ,e.EmpName, e.EmpCity,e.EmpExp,e.EmpMoNo));
                                exist = true;
                            }
                        }
                        if (!exist)
                        {
                            Console.WriteLine("The Employee is not exist");
                        }
                    }
                    break;

                case 4:
                   if(EmpData.Count == 0)
                    {
                        Console.WriteLine("The Employee List Is Empty");
                    }
                    else
                    {
                        Console.Write("Enter employee Number for Remove:");
                        string RemoveEmp = Console.ReadLine();
                        bool exist = false;
                        foreach (Menu e in EmpData)
                        {
                            if (e.EmpNo == RemoveEmp)
                            {
                                EmpData.Remove(e);
                                Console.WriteLine("Employee deleted Successfully");
                                exist = true;
                                break;
                            }
                        }
                        if(!exist)
                        {
                            Console.WriteLine("Please enter valid Employee Number");
                        }

                    }
                    break;

                case 6:
                    if (EmpData.Count == 0)
                    {
                        Console.WriteLine("The Employee List Is Empty");
                    }
                    else
                    {
                        Console.WriteLine("Enter Employee Number for Update:");

                    }
                    break;
                case 5:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Enter valid Choice Number:");
                    break;

            }
            Console.Write("Do You Want to Do any Other Operation(Y/N):");
            string userchoice = Console.ReadLine();
            if (userchoice == "y"||userchoice == "Y")
            {
                goto startconsole;
            }
            else
            {
                Environment.Exit(0);
            }

        }
    }
}
