using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System;
//using SeleniumExtras.WaitHelpers;

namespace My_Nunit
{
    [TestFixture]
    public class NunitTest
    {
         IWebDriver driver;

        [SetUp]
        public void Initialize()
        {
            driver = new ChromeDriver();
            Thread.Sleep(2000);
            driver.Manage().Window.Maximize();
            driver.Url = "https://docs.google.com/forms/d/e/1FAIpQLSfheX-lBN1r477rwQ1tigtXmYgpNScgZzPV8Y9Nqe-2EHMZew/viewform";
            Thread.Sleep(2000);
            var Uname = driver.FindElement(By.Id("identifierId"));
            Uname.SendKeys("ritesh@atharvasystem.com");
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//input[@type='password']")).SendKeys("ritz@6011");
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(3000);
        }
        [Test]
        public void SprintReview()
        {

            driver.FindElement(By.XPath("//span[contains(text(), 'Sprint')]//ancestor::div[@class='bzfPab wFGF8']//descendant::div[@class='vd3tt']")).Click();            
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(5000);
        }
        [Test]
        public void StoryReview()
        {
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Daily Status')]")).Click();
            Thread.Sleep(5000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(5000);

        }
        [TearDown]
        public void EndTest()
        {
            //driver.Close();
        }
    }
}